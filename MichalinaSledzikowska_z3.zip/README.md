# KenazEngine

A project for **2D Computer Games** subject.

# Objectives

- Create simple game engine for 2D games, using **SDL2**
- Create game that uses this engine

# Things created so far

- Display stuff on screen
- Map loader
- Texture loader
- Allow two players to play at the same time
- Joystick handler
